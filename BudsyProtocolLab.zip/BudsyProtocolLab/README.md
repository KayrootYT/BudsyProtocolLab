# Budsy Protocol Lab (Android source)

A native Android BLE GATT explorer aimed at OnePlus Nord Buds 3 research.

## Current features
- Runtime Bluetooth permissions for Android 12+ and legacy location permission for Android 6–11.
- BLE scan, device selection, GATT connection and service discovery.
- Characteristic UUID/property listing.
- Manual characteristic reads and notification/indication subscription attempts.
- Explicitly confirmed HEX writes only when the characteristic supports write.
- Timestamped on-screen log for scan/connect/disconnect, read results, notification payloads, write requests and results.
- CSV export to Downloads on Android 10+.
- Dark compact UI with orange accents.

## Important limits
- This app logs GATT operations it performs and notifications it subscribes to. It **does not passively intercept HeyMelody's traffic**. Android generally does not allow one app to read another app's private Bluetooth writes.
- Proprietary payloads are not automatically decoded. Unknown writes can change device settings or disconnect the earbuds; use only payloads you understand.
- Physical testing on OnePlus Nord Buds 3 has not been performed here. Device firmware behavior and notifications are unverified.
- This source has not been compiled in this environment. Open the folder in Android Studio with Android Gradle Plugin 8.7.3 and compile SDK 35 installed.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install the requested SDK/platform tools.
3. Build an APK and install on Android 12+.
4. Grant Nearby devices permissions, enable Bluetooth, put the earbuds in a discoverable/connected state, then tap Scan BLE.

## Capturing HeyMelody's actual protocol
For actual app-originated command packets, use Android Bluetooth HCI snoop logging (Developer options, where available), reproduce one setting change in HeyMelody, then analyze the resulting btsnoop log with an appropriate packet analyzer. Availability and visibility vary by phone/vendor/Android version. Disconnect HeyMelody before connecting this app to avoid GATT contention.
