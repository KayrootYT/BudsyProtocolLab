package com.budsy.protocollab;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.BluetoothStatusCodes;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(18,18,20), panel = Color.rgb(35,35,39), orange = Color.rgb(255,132,48), white = Color.WHITE, muted = Color.rgb(185,185,192);
    private LinearLayout root, content, deviceList, servicesBox, logBox;
    private TextView status;
    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt gatt;
    private final Map<String, BluetoothDevice> found = new HashMap<>();
    private final Map<String, BluetoothGattCharacteristic> chars = new HashMap<>();
    private final ArrayList<String> logLines = new ArrayList<>();
    private boolean scanning = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private String connectedName = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        BluetoothManager manager = (BluetoothManager)getSystemService(BLUETOOTH_SERVICE);
        adapter = manager == null ? null : manager.getAdapter();
        buildUi(); requestBtPermissions();
    }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(22),dp(16),dp(24)); root.setBackgroundColor(bg); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);
        TextView title = text("BUDSY  /  PROTOCOL LAB", 23, white); title.setTypeface(null,1); root.addView(title);
        TextView subtitle = text("OnePlus Nord Buds 3 · BLE GATT inspector", 14, muted); root.addView(subtitle);
        status = text("Not connected",14,orange); status.setPadding(0,dp(10),0,dp(12)); root.addView(status);
        LinearLayout buttons = row(); addButton(buttons,"Scan BLE",this::startScan); addButton(buttons,"Stop scan",this::stopScan); addButton(buttons,"Disconnect",this::disconnect); root.addView(buttons);
        section("Nearby devices"); deviceList = new LinearLayout(this); deviceList.setOrientation(LinearLayout.VERTICAL); root.addView(deviceList);
        section("GATT services & characteristics"); servicesBox = new LinearLayout(this); servicesBox.setOrientation(LinearLayout.VERTICAL); root.addView(servicesBox);
        section("Packet log"); TextView note = text("Logs only operations performed by this tool. It cannot passively intercept HeyMelody app traffic.",12,muted); root.addView(note);
        LinearLayout logButtons = row(); addButton(logButtons,"Export log",this::exportLog); addButton(logButtons,"Clear log",this::clearLog); root.addView(logButtons);
        logBox = new LinearLayout(this); logBox.setOrientation(LinearLayout.VERTICAL); root.addView(logBox);
        TextView foot = text("Safety: arbitrary BLE writes may change earbud settings or disconnect them. Write is always manual and requires confirmation. Unknown payloads are not decoded automatically.",12,muted); foot.setPadding(0,dp(16),0,0); root.addView(foot);
    }
    private void requestBtPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            ArrayList<String> p = new ArrayList<>(); if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_SCAN); if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) p.add(Manifest.permission.BLUETOOTH_CONNECT); if (!p.isEmpty()) requestPermissions(p.toArray(new String[0]), 8);
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},8);
    }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results) { super.onRequestPermissionsResult(requestCode,permissions,results); if(requestCode==8){ boolean ok=true; for(int r:results) if(r!=PackageManager.PERMISSION_GRANTED) ok=false; if(!ok) toast("Bluetooth permission denied. Grant permissions to scan/connect."); } }
    private void startScan() {
        if (adapter == null || !adapter.isEnabled()) { toast("Turn Bluetooth on first."); return; }
        if (Build.VERSION.SDK_INT >= 31 && (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN)!=PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED)) { requestBtPermissions(); return; }
        try { scanner=adapter.getBluetoothLeScanner(); if(scanner==null){toast("BLE scanner unavailable.");return;} found.clear(); deviceList.removeAllViews(); scanner.startScan(scanCallback); scanning=true; status.setText("Scanning nearby BLE devices…"); addLog("SCAN_START", "", "", "started"); handler.postDelayed(this::stopScan,12000); } catch(Exception e){ addLog("SCAN_ERROR","","",e.toString()); toast("Scan failed: "+e.getMessage()); }
    }
    private final ScanCallback scanCallback = new ScanCallback() {
        @Override public void onScanResult(int callbackType, ScanResult result) { runOnUiThread(() -> { BluetoothDevice d=result.getDevice(); String key=d.getAddress(); if(found.containsKey(key)) return; found.put(key,d); String name=""; try{name=d.getName();}catch(SecurityException ignored){} if(name==null||name.trim().isEmpty()) name="Unnamed BLE device"; final String shown=name; LinearLayout card=card(); card.addView(text(shown+"\n"+key+" · RSSI "+result.getRssi()+" dBm",14,white),new LinearLayout.LayoutParams(0,-2,1)); Button connect=button("Connect"); connect.setOnClickListener(v->connect(d,shown)); card.addView(connect); deviceList.addView(card); }); }
        @Override public void onScanFailed(int errorCode){runOnUiThread(()->{scanning=false; status.setText("Scan failed: "+errorCode); addLog("SCAN_ERROR","","",String.valueOf(errorCode));});}
    };
    private void stopScan() { if(scanner!=null && scanning){try{scanner.stopScan(scanCallback);}catch(Exception ignored){} scanning=false; addLog("SCAN_STOP","","","stopped"); if(gatt==null) status.setText("Scan stopped · select a device");} }
    private void connect(BluetoothDevice device,String name) { stopScan(); try { if(gatt!=null) gatt.close(); connectedName=name; status.setText("Connecting to "+name+"…"); addLog("CONNECT","","",name); gatt=device.connectGatt(this,false,gattCallback, BluetoothDevice.TRANSPORT_LE); } catch(Exception e){addLog("CONNECT_ERROR","","",e.toString());toast("Connect failed: "+e.getMessage());} }
    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override public void onConnectionStateChange(BluetoothGatt g,int statusCode,int newState) { runOnUiThread(()->{ if(newState==BluetoothProfile.STATE_CONNECTED){status.setText("GATT connected · "+connectedName+" · discovering services"); addLog("CONNECTED","","","GATT connected"); g.discoverServices();} else if(newState==BluetoothProfile.STATE_DISCONNECTED){status.setText("Disconnected"); addLog("DISCONNECTED","","","status="+statusCode); servicesBox.removeAllViews(); chars.clear(); g.close(); if(gatt==g)gatt=null;} }); }
        @Override public void onServicesDiscovered(BluetoothGatt g,int statusCode) { runOnUiThread(()->{servicesBox.removeAllViews();chars.clear(); if(statusCode!=BluetoothGatt.GATT_SUCCESS){addLog("SERVICE_DISCOVERY_ERROR","","",String.valueOf(statusCode));return;} for(android.bluetooth.BluetoothGattService s:g.getServices()){ TextView st=text("SERVICE  "+s.getUuid(),14,orange); st.setPadding(0,dp(12),0,dp(4)); servicesBox.addView(st); for(BluetoothGattCharacteristic c:s.getCharacteristics()){String key=c.getUuid().toString(); chars.put(key,c); String props=properties(c.getProperties()); LinearLayout card=card(); LinearLayout col=new LinearLayout(MainActivity.this);col.setOrientation(LinearLayout.VERTICAL);col.addView(text(key,13,white));col.addView(text(props,12,muted));card.addView(col,new LinearLayout.LayoutParams(0,-2,1)); LinearLayout actions=row(); if((c.getProperties()&BluetoothGattCharacteristic.PROPERTY_READ)!=0)addButton(actions,"Read",()->read(c)); if((c.getProperties()&(BluetoothGattCharacteristic.PROPERTY_NOTIFY|BluetoothGattCharacteristic.PROPERTY_INDICATE))!=0)addButton(actions,"Notify",()->subscribe(c)); if((c.getProperties()&(BluetoothGattCharacteristic.PROPERTY_WRITE|BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE))!=0)addButton(actions,"Write",()->writeDialog(s.getUuid().toString(),c)); card.addView(actions); servicesBox.addView(card); } } addLog("SERVICES_DISCOVERED","","",g.getServices().size()+" services"); }); }
        @Override public void onCharacteristicRead(BluetoothGatt g,BluetoothGattCharacteristic c,int statusCode) { byte[] b=c.getValue(); runOnUiThread(()->addLog("READ",serviceUuid(c),c.getUuid().toString(),"status="+statusCode+" HEX="+hex(b)+" UTF8="+utf8(b))); }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c,byte[] value) { byte[] b=value.clone(); runOnUiThread(()->addLog("NOTIFY",serviceUuid(c),c.getUuid().toString(),"HEX="+hex(b)+" UTF8="+utf8(b))); }
        @Override public void onCharacteristicChanged(BluetoothGatt g,BluetoothGattCharacteristic c) { byte[] b=c.getValue()==null?new byte[0]:c.getValue().clone(); runOnUiThread(()->addLog("NOTIFY",serviceUuid(c),c.getUuid().toString(),"HEX="+hex(b)+" UTF8="+utf8(b))); }
        @Override public void onCharacteristicWrite(BluetoothGatt g,BluetoothGattCharacteristic c,int statusCode) { runOnUiThread(()->addLog("WRITE_RESULT",serviceUuid(c),c.getUuid().toString(),"status="+statusCode)); }
        @Override public void onDescriptorWrite(BluetoothGatt g,BluetoothGattDescriptor d,int statusCode) { runOnUiThread(()->addLog("SUBSCRIBE_RESULT","",d.getUuid().toString(),"status="+statusCode)); }
    };
    private void read(BluetoothGattCharacteristic c){try{boolean ok=gatt!=null&&gatt.readCharacteristic(c);addLog("READ_REQUEST",serviceUuid(c),c.getUuid().toString(),ok?"queued":"request rejected");}catch(Exception e){addLog("READ_ERROR",serviceUuid(c),c.getUuid().toString(),e.toString());}}
    private void subscribe(BluetoothGattCharacteristic c){ if(gatt==null)return; try { boolean ok=gatt.setCharacteristicNotification(c,true); BluetoothGattDescriptor d=c.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")); if(d!=null){byte[] value=(c.getProperties()&BluetoothGattCharacteristic.PROPERTY_INDICATE)!=0?BluetoothGattDescriptor.ENABLE_INDICATION_VALUE:BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; if(Build.VERSION.SDK_INT>=33)gatt.writeDescriptor(d,value);else{d.setValue(value);gatt.writeDescriptor(d);}} addLog("SUBSCRIBE_REQUEST",serviceUuid(c),c.getUuid().toString(),ok?"local notification enabled":"enable failed or descriptor missing"); }catch(Exception e){addLog("SUBSCRIBE_ERROR",serviceUuid(c),c.getUuid().toString(),e.toString());}}
    private void writeDialog(String service,BluetoothGattCharacteristic c){ EditText input=new EditText(this);input.setHint("Hex bytes, e.g. 01 A0 FF"); new AlertDialog.Builder(this).setTitle("Write characteristic?").setMessage("Unknown BLE writes may change earbud settings, cause disconnects, or have other effects. Only send a payload you understand.").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Confirm write",(d,w)->{String raw=input.getText().toString().trim();try{String cleaned=raw.replace("0x","").replaceAll("[^0-9A-Fa-f]","");if(cleaned.isEmpty()||cleaned.length()%2!=0)throw new IllegalArgumentException("Use an even number of hex digits.");byte[] bytes=new byte[cleaned.length()/2];for(int i=0;i<bytes.length;i++)bytes[i]=(byte)Integer.parseInt(cleaned.substring(i*2,i*2+2),16);int type=(c.getProperties()&BluetoothGattCharacteristic.PROPERTY_WRITE)!=0?BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT:BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE;boolean queued=false;if(Build.VERSION.SDK_INT>=33){int r=gatt.writeCharacteristic(c,bytes,type);queued=r==BluetoothStatusCodes.SUCCESS;}else{c.setWriteType(type);c.setValue(bytes);queued=gatt.writeCharacteristic(c);}addLog("WRITE_REQUEST",service,c.getUuid().toString(),"HEX="+hex(bytes)+" queued="+queued);if(!queued)toast("Write request was not queued.");}catch(Exception e){toast("Invalid write: "+e.getMessage());}}).show(); }
    private void disconnect(){stopScan();if(gatt!=null){try{gatt.disconnect();}catch(Exception ignored){} addLog("DISCONNECT_REQUEST","","","requested");}else status.setText("Not connected");}
    private void exportLog(){try{StringBuilder b=new StringBuilder("timestamp,event,service_uuid,characteristic_uuid,details\n");for(String line:logLines)b.append('"').append(line.replace("\"","\"\"").replace("\n"," ")).append("\"\n");String filename="budsy-protocol-log-"+System.currentTimeMillis()+".csv";android.content.ContentValues v=new android.content.ContentValues();v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,filename);v.put(android.provider.MediaStore.Downloads.MIME_TYPE,"text/csv");if(Build.VERSION.SDK_INT>=29){android.net.Uri uri=getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);if(uri!=null){try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){out.write(b.toString().getBytes(StandardCharsets.UTF_8));}toast("CSV exported to Downloads: "+filename);}}else toast("Export requires Android 10+");}catch(Exception e){toast("Export failed: "+e.getMessage());}}
    private void clearLog(){new AlertDialog.Builder(this).setTitle("Clear packet log?").setMessage("This removes the current on-screen log.").setNegativeButton("Cancel",null).setPositiveButton("Clear",(d,w)->{logLines.clear();logBox.removeAllViews();}).show();}
    private void addLog(String event,String service,String characteristic,String details){String line=stamp()+" | "+event+" | "+service+" | "+characteristic+" | "+details;logLines.add(line);TextView t=text(line,11,muted);t.setPadding(0,dp(5),0,dp(5));logBox.addView(t,0);if(logLines.size()>500){logLines.remove(0);if(logBox.getChildCount()>0)logBox.removeViewAt(logBox.getChildCount()-1);}}
    private String serviceUuid(BluetoothGattCharacteristic c){try{return c.getService().getUuid().toString();}catch(Exception e){return "";}}
    private String properties(int p){ArrayList<String>a=new ArrayList<>();if((p&2)!=0)a.add("READ");if((p&4)!=0)a.add("WRITE_NO_RESPONSE");if((p&8)!=0)a.add("WRITE");if((p&16)!=0)a.add("NOTIFY");if((p&32)!=0)a.add("INDICATE");if((p&1)!=0)a.add("BROADCAST");return a.isEmpty()?"No common properties":android.text.TextUtils.join(" · ",a);}
    private String hex(byte[] b){if(b==null)return "";StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02X ",x&255));return s.toString().trim();}
    private String utf8(byte[] b){if(b==null)return "";String s=new String(b,StandardCharsets.UTF_8);return s.replaceAll("[^\\x20-\\x7E]",".");}
    private String stamp(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",Locale.US).format(new Date());}
    private void section(String s){TextView t=text(s,17,white);t.setTypeface(null,1);t.setPadding(0,dp(20),0,dp(8));root.addView(t);}
    private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(12),dp(10),dp(12),dp(10));l.setBackgroundColor(panel);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(4),0,dp(4));l.setLayoutParams(p);return l;}
    private void addButton(LinearLayout parent,String label,Runnable action){Button b=button(label);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1);p.setMargins(dp(2),dp(3),dp(2),dp(3));parent.addView(b,p);b.setOnClickListener(v->action.run());}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(white);b.setTextSize(12);b.setAllCaps(false);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(orange));return b;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override protected void onDestroy(){stopScan();if(gatt!=null){gatt.close();gatt=null;}super.onDestroy();}
}
